    <footer>
        <script src="js/responsive.js"></script>
        <a href="aboutUS.html"><img src="img/about.png" alt="about" width="30"></a>
    </footer>