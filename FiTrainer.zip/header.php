    <header>
        <nav class="topnav" id="topNav">
            <img src="img/logoFT cuadrado.png" alt="logo" width="48" logo>
            <a href="perfil.php?unset=true" class="responsiveTitle">- FiTrainer</a>
            <a href="microciclo.php?unset=true">Microciclo</a>
            <a href="Dietas.php?unset=true">Dieta</a>
            <a href="Consultas.php?unset=true">Consultas</a>
            <a href="Pruebas.php?unset=true" >Pruebas</a>
            <a href="reuniones.php?unset=true" >Reuniones</a>
            <a href="competiciones.php?unset=true">Competiciones</a>
            <a href="pagos.php?unset=true" >Pagos</a>
            <a href="perfil.php?unset=true" class="floatRight"><img src="img/profile.png" alt="profile" width="20"></a>
            <a href="logOut.php?unset=true" class="floatRight"><img src="img/power.png" alt="off" width="20"></a>
            <a href="javascript:void(0);" class="icon" onclick="responsive()"><img src="img/dropdown.png" alt="profile" width="20"></a>
        </nav>
    </header>
