<header>
    <nav class="topnav" id="topNav">
        <img src="img/logoFT cuadrado.png" alt="logo" width="48" logo>
        <a href="perfil.php?unset=true" class="responsiveTitle">- FiTrainer</a>
        <a href="seleccionAtleta.php?unset=true">Atletas</a>
        <a href="introducirEjercicio.php?unset=true">Ejercicios</a>
        <a href="introducirReunion.php?unset=true">Reuniones</a>
        <a href="introducirCompeticion.php?unset=true">Competiciones</a>
        <a href="logOut.php" class="floatRight"><img src="img/power.png" alt="off" width="20"></a>
        <a href="javascript:void(0);" class="icon" onclick="responsive()"><img src="img/dropdown.png" alt="profile" width="20"></a>
    </nav>
</header>